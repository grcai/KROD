addpath ('../data/');
addpath ('../tools/');



%load('Isolet.mat')
%load('lung.mat') 
%load('TOX-171.mat') 
%load('Jaffe.mat')
%load('USPS.mat') 
%load('Mnist_test.mat') 
%load('COIL20.mat')
load('COIL100.mat') 


fea = double(X);
fea = Data_Normalized(fea);
groupNumber = length(unique(Y));

disp('--------------------------Clustering--------------------------');
cl = predict_nmf_lp(fea, groupNumber);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)