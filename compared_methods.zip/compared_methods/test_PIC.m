


clear
clc

addpath ('../data/');
addpath ('../tools/');
addpath ('./tools/gacfiles/');

load('Isolet.mat') % k = 25 v = 10
%load('lung.mat') % k = 15 v = 10
%load('TOX-171.mat') % k = 15 v = 10
%load('Jaffe.mat') % k = 15  v = 10
%load('COIL20.mat') % k = 5  v = 1
%load('USPS.mat') % k = 20 v = 1 
%load('Mnist_test.mat') % k = 25 v = 1
%load('COIL100.mat') % k = 10 v = 1 


%Normalize and compute the similarities.
fea = double(X);
fea = Data_Normalized(fea);   
dist = dis2(fea, fea); 
dist = dist - diag(diag(dist));

%% clustering
K = 25;  
v = 10;  
z = 0.01;
strDescr = 'path';
groupNumber = length(unique(Y));


ND = size(dist,1);
dist = dist - diag(diag(dist));
tic
disp('--------------------------Clustering--------------------------');
[graphW, NNIndex] = gacBuildDigraph(dist, K, v);
graphW=roundn(graphW,-4);
graphW = bsxfun(@times, 1./sum(graphW,2), graphW); % row sum is 1
initialClusters = gacNNMerge(dist, NNIndex);
numClusters = length(initialClusters);
cl = gacMerging(graphW, initialClusters, groupNumber, strDescr, z);
toc

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)