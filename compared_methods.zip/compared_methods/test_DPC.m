clear
clc

addpath ('../data/');
addpath ('../tools/');

%load('COIL20.mat') % p = 2 
%load('TOX-171.mat') % p = 2 
%load('lung.mat') % p = 2  
%load('Isolet.mat') % p = 2 
%load('USPS.mat') % p = 1.5
%load('Mnist_test.mat') % p = 0.5 
%load('Jaffe.mat') % p = 1.5
%load('COIL100.mat') % p = 2

fea = double(X);
fea = Data_Normalized(fea);


p = 2;
groupNumber = length(unique(Y));


disp('--------------------------Clustering--------------------------');
tic
cl = cluster_dp2(fea,groupNumber, p);
toc
NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)