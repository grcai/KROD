


clear
clc

addpath ('../data/');
addpath ('../tools/');
addpath ('./tools/gdlfiles/');

%load('Isolet.mat') % K = 25 v = 10
%load('lung.mat') % K = 15 v = 0.1
%load('TOX-171.mat') % K = 10 v = 10
%load('Jaffe.mat') % K = 15  v = 10
%load('COIL20.mat') % K = 5  v = 1
%load('USPS.mat') % K = 20 v = 1 
%load('Mnist_test.mat') % K = 25 v = 1
%load('COIL100.mat') % K = 10 v = 1 



%Normalize and compute the similarities.
fea = double(X);
fea = Data_Normalized(fea);   
dist = dis2(fea, fea); 
dist = dist - diag(diag(dist));

%% clustering
k = 10;  
v = 10; 
groupNumber = length(unique(Y));

ND = size(dist,1);
dist = dist - diag(diag(dist));


disp('--------------------------Clustering--------------------------');
cl = gdlCluster(dist, groupNumber, k, v, true);

NMI1 = nmi(cl,Y)
label = bestMap(Y,cl);
AC1= length(find(label == Y))/length(Y)