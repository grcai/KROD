%% Our new similarity for COIL20 dataset with path agglomerative Clustering method.
% For Path agglomerative clustering method the reference is as follow:
% W. Zhang, D. Zhao, and X. Wang, ��Agglomerative clustering via maximum incremental 
% path integral,�� Pattern Recognition, vol. 46, no. 11, pp. 3056�C3065,2013.



clear
clc

addpath ('../data/');
addpath ('../tools/');

%load('Isolet.mat') % K=5
%load('lung.mat') %  K=25
%load('TOX-171.mat') % K = 10 
%load('Jaffe.mat') % K = 5
%load('USPS.mat') % K = 25
%load('Mnist_test.mat') % K=15
%load('COIL20.mat') %K=10
%load('COIL100.mat') % K= 5

fea = double(X);
fea = Data_Normalized(fea);
fea = PCA(fea,150);




%% clustering
K = 5;
groupNumber = length(unique(Y));

disp('--------------------------Clustering--------------------------');
cl =  knncluster_dp2(fea,groupNumber, K);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)