addpath ('../data/');
addpath ('../tools/');


%load('Isolet.mat') % K=20
%load('lung.mat') %  K=20
%load('TOX-171.mat') % K = 10 
%load('Jaffe.mat') % K = 20
%load('USPS.mat') % K = 20
%load('Mnist_test.mat') % K=25
load('COIL20.mat') % K=5
%load('COIL100.mat') % K= 5 

tic
K = 5;
groupNumber = length(unique(Y));

fea = double(X);
fea = Data_Normalized(fea);


disp('--------------------------Clustering--------------------------');
A0 = constructW_PKN(fea', K, 1);
[cl, S, evs, cs] = CLR(A0, groupNumber,0,1);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)
toc