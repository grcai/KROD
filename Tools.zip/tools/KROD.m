function rodist = rank_dis_c(fea,a)

disp('Computing KRODs between samples...');

dist = dis2(fea,fea);
dist = dist./max(max(dist));
[~,list] = sort(dist,2);
[~,rows] = sort(list,2);
rodist = (rows + rows');
rodist =  rodist./max(max(rodist));
rodist = rodist .* exp(dist.^2 ./ a);
