
function cl = knncluster_dp(fea,k, K)
NUC = k;


dist = dis2(fea,fea);
dist = dist - diag(diag(dist));
ND = size(dist,1);
N = ND^2;

% fprintf('average percentage of neighbours (hard coded): %5.6f\n', percent);

for i = 1:ND
    dist(i,i) = 0;
end
percent = 2;
position=round(N*percent/100);
xx=reshape(dist,N,1);
sda=sort(xx);
dc=sda(position);

% fprintf('Computing Rho with gaussian kernel of radius: %12.6f\n', dc);


for i=1:ND
  rho(i)=0;
end


dist_copy=dist;

for i=1:ND
    dist_copy(:,i)=sort(dist_copy(:,i),'ascend');
end
for i=2:K+1
    rho=rho+dist_copy(i,:).^2;
end
rho=exp(-1/k*rho);

%"Cut off" kernel

% for i=1:ND-1
%  for j=i+1:ND
%    if (dist(i,j)<dc)
%       rho(i)=rho(i)+1.;
%       rho(j)=rho(j)+1.;
%    end
%  end
% end

maxd=max(max(dist));

[~,ordrho]=sort(rho,'descend');
delta(ordrho(1))=-1.;
nneigh(ordrho(1))=0;

for ii=2:ND
   delta(ordrho(ii))=maxd;
   for jj=1:ii-1
     if(dist(ordrho(ii),ordrho(jj))<delta(ordrho(ii)))
        delta(ordrho(ii))=dist(ordrho(ii),ordrho(jj));
        nneigh(ordrho(ii))=ordrho(jj);
     end
   end
end
delta(ordrho(1))=max(delta(:));

NCLUST=0;
for i=1:ND
  cl(i)=-1;
end

rank=rho.*delta;
[~,index]=sort(rank,'descend');
for i=1:NUC
     NCLUST=NCLUST+1;
     cl(index(i))=NCLUST;
     icl(NCLUST)=index(i);
end


for i=1:ND
  if (cl(ordrho(i))==-1)
    cl(ordrho(i))=cl(nneigh(ordrho(i)));
  end
end
%halo
for i=1:ND
  halo(i)=cl(i);
end
if (NCLUST>1)
  for i=1:NCLUST
    bord_rho(i)=0.;
  end
  for i=1:ND-1
    for j=i+1:ND
      if ((cl(i)~=cl(j))&& (dist(i,j)<=dc))
        rho_aver=(rho(i)+rho(j))/2.;
        if (rho_aver>bord_rho(cl(i))) 
          bord_rho(cl(i))=rho_aver;
        end
        if (rho_aver>bord_rho(cl(j))) 
          bord_rho(cl(j))=rho_aver;
        end
      end
    end
  end
  for i=1:ND
    if (rho(i)<bord_rho(cl(i)))
      halo(i)=0;
    end
  end
end
for i=1:NCLUST
  nc=0;
  nh=0;
  for j=1:ND
    if (cl(j)==i) 
      nc=nc+1;
    end
    if (halo(j)==i) 
      nh=nh+1;
    end
  end
end



%end