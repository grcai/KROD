
function rodist = KROD(fea,a)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The function to compute KROD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute our improved ROD

dist = dis2(fea,fea);
dist = dist./max(max(dist));
[~,list] = sort(dist,2);
[~,rows] = sort(list,2);
rodist = (rows + rows');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Compute KROD

rodist =  rodist./max(max(rodist));
rodist = rodist .* exp(dist.^2 ./ a);
