%% KROD with DPC clustering method


clear
clc

addpath ('./data/');
addpath ('./tools/');

%load('COIL20.mat') % p = 1.5 u = 100
%load('TOX-171.mat') % p = 2 u = 10 
%load('lung.mat') % p = 2 u = 0.1  
%load('Isolet.mat') % p = 0.5 u = 1 
%load('USPS.mat') % p = 0.2 u = 1 
%load('Mnist_test.mat') % p = 0.2 u =1
load('Jaffe.mat') % p = 1.5 u = 0.1 
%load('COIL100.mat') % p = 0.5 u = 10  

fea = double(X);
u = 0.1; 
fea = Data_Normalized(fea);



%% clustering
p = 1.5;
groupNumber = length(unique(Y));

cl = cluster_dp1(fea,groupNumber, p,u);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)