KROD_clustering_box
==========

Introduction
------------

KROD_clustering_box is a summary of our new distance (KROD) and its application in clustering.
There are four KROD based clustering methods: KROD-DPC, KRPD-PK-DPC, KROD-PIC and KROD-GDL.

You can use any test-dataset with its suggested parameters to test our methods.
The test-code is written in test_KROD_DPC, test_KRPD_PK_DPC, test_KROD_PIC and KROD_GDL.
COIL100 dataset is to big to upload.
You can down load it from http://www.cs.columbia.edu/CAVE/software/softlib/coil-100.php

If our KROD is useful for you, please cite 
Huang, T., Wang, S. & Zhu, W. An adaptive kernelized rank-order distance for clustering non-spherical data with high noise. Int. J. Mach. 
Learn. & Cyber. (2020). https://doi.org/10.1007/s13042-020-01068-9.








