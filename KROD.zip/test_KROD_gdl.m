%% KROD with GDL clustering method


clear
clc

addpath ('./data/');
addpath ('./tools/');


%load('Isolet.mat') % k = 25 u = 1 v = 10
%load('lung.mat') % k = 10 u = 0.1 v = 1
%load('TOX-171.mat') % k = 10 u = 1 v = 10
%load('Jaffe.mat') % k = 10 u = 1 v = 1
load('COIL20.mat') % k = 5 u = 1 v = 1
%load('USPS.mat') % k = 10 u = 100 v = 100 
%load('Mnist_test.mat') % k = 25 u = 100 v = 10 
%load('COIL100.mat') % k = 25 u = 100 v = 0.1 



%Normalize and compute the similarities.
fea = double(X);
u = 1; 
fea = Data_Normalized(fea);   
dist = KROD(fea, u);
dist = dist - diag(diag(dist));
dist = dist .* dist;
%% clustering
K = 5;  % the parameter K in of our similarity
v =1; % the parameter a in of our similarity
groupNumber = length(unique(Y));  

ND = size(dist,1);
dist = dist - diag(diag(dist));
disp('---------- Building graph and forming initial clusters with l-links ---------');

% build the adjacency graph



disp('-------------------------- merging --------------------------');
cl = gdlCluster(dist, groupNumber, K, v, true);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC= length(find(label == Y))/length(Y)