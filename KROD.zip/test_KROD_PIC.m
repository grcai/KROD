%% KROD with PIC clustering method


clear
clc

addpath ('./data/');
addpath ('./tools/');

load('COIL20') % k = 10 u = 1 v = 0.1
%load('TOX-171.mat') % k = 5 u = 1 v = 10
%load('lung.mat') % k = 15 u = 0.1 v = 1
%load('Jaffe.mat') % k = 10 u = 1 v = 1
%load('Isolet.mat') % k = 20 u = 10 v = 1
%load('USPS.mat') % k = 10 u = 100 v = 100 
%load('Mnist_test.mat') % k = 25 u = 10 v = 10 
%load('COIL100.mat') % k = 25 u = 1 v = 0.1


fea = double(X);
u = 1; 
fea = Data_Normalized(fea);   
dist = KROD(fea, u); 
dist = dist - diag(diag(dist));
dist = dist .* dist;
%% clustering
K = 10;  
v = 0.1;  
z = 0.01;
strDescr = 'path';
groupNumber = length(unique(Y));   %The cluster number.
ND = size(dist,1);
dist = dist - diag(diag(dist));
disp('---------- Building graph and forming initial clusters with l-links ---------');

% build the adjacency graph
[graphW, NNIndex] = gacBuildDigraph(dist, K, v);
graphW=roundn(graphW,-4);
% from adjacency matrix to probability transition matrix
graphW = bsxfun(@times, 1./sum(graphW,2), graphW); % row sum is 1
initialClusters = gacNNMerge(dist, NNIndex);
numClusters = length(initialClusters);


disp('-------------------------- merging --------------------------');
cl = gacMerging(graphW, initialClusters, groupNumber, strDescr, z);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)