%% KROD with PK_DPC clustering method


clear
clc

addpath ('./data/');
addpath ('./tools/');

load('Isolet.mat') % K=25 u = 10 
%load('lung.mat') %  K=10 u = 0.1 
%load('TOX-171.mat') % K = 10 u = 10
%load('Jaffe.mat') % K = 10  u = 0.1 
%load('USPS.mat') % K = 20 u = 1 
%load('Mnist_test.mat') % K=20 u =1 
%load('COIL20.mat') %K=25 u = 1
%load('COIL100.mat') % K= 25 u = 1 

fea = double(X);
u = 10; %the parameter sigma^2 in of our similarity
fea = Data_Normalized(fea);
fea = PCA(fea,150);




%% clustering
K = 25;
groupNumber = 26;

cl =  knncluster_dp1(fea,groupNumber, K, u);

NMI = nmi(cl,Y)
label = bestMap(Y,cl);
AC = length(find(label == Y))/length(Y)